
public class Reta  extends Shape{

	
	public Reta()
	{
		  //Seta altura maxima do desenho
		   setTamanhoMaximo();
	}
	
	///plotar linha
	public void Draw(Ponto p0, Ponto p1)
	{
		
		
		int x1 = p0.x;
		int y1 = p0.y;
		int x2 = p1.x;
		int y2 = p1.y;		
		int slope;
		int dx, dy, incE, incNE, d, x, y;
		
	   // Onde inverte a linha x1 > x2       
   	   if (x1 > x2){
   			//bresenham1(x2, y2, x1, y1);
            Draw(new Ponto(x2, y2), new Ponto( x1, y1));
            return;
       }        
       dx = x2 - x1;
       dy = y2 - y1;
   
       if (dy < 0){            
           slope = -1;
           dy = -dy;
       }
       else{            
          slope = 1;
       }
       // Constante de Bresenham
	   incE = 2 * dy;
	   incNE = 2 * dy - 2 * dx;
	   d = 2 * dy - dx;
	   y = y1;       
	   
	   if(x1 == x2 && y1 != y2)
	   {
		   for (x = x1; x <= x2; x++){		  
			   for (y = y1; y <= y2; y++)
			   {
			       setPixel(new Ponto(x,y), cor);
			       if (d <= 0){	
			    	   
			    	   //coloquei
			    	   if(incE == 0)
			    		   incE = 1;
			    	   
			         d += incE;
			       }
			       else{
			         d += incNE;
			         //y += slope;
			       }
			   }
		   }
		   
	   }
	   else
	   {
		   for (x = x1; x <= x2; x++){		  
			   //for (y = y1; y <= y2; y++)
			   //{
			       setPixel(new Ponto(x,y), cor);
			       if (d <= 0){	
			    	   
			    	   //coloquei
			    	   if(incE == 0)
			    		   incE = 1;
			    	   
			         d += incE;
			       }
			       else{
			         d += incNE;
			         y += slope;
			       }
			   //}
		   }
	   }
				
	}
	
}

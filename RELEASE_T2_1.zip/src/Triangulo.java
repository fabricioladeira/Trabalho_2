
public class Triangulo extends Shape{
		
	public  void Draw(int X0 , int Y0, int X1, int Y1, int X2, int Y2)
	{	
		
		Reta reta = new Reta();
		//reta.Draw(new Ponto(X0,Y0), new Ponto(X1,Y1));
		reta.Draw(new Ponto(X2, Y2), new Ponto(X0, Y0));
		reta.Draw(new Ponto(X2,Y2), new Ponto(X1, Y1));
		reta.Draw(new Ponto(X0,Y0), new Ponto(X1, Y1));
		
	}

}

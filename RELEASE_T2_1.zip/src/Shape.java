
public abstract class Shape {

	
	public int largura = 100;
	public int altura = 100;
	public static int[][] matriz = new int[100][100];	
	public Cor cor = new Cor(255,255,255,"G");
	
	public void Draw(Cor pCor)
	{
		cor = pCor;
	}
	
	///Seta tamanho maximo do desenho
	public void setTamanhoMaximo()
	{		
	   //Seta altura maxima do desenho
	   largura = Imagem.getLargura();
	   altura = Imagem.getAltura();
	   
	   matriz = new int[largura][altura];
	}
	
	
	public void setPixel(Ponto p, Cor c )
	{	
		if(c.getTipoCor()=="C")
			matriz[p.y][p.x] = c.getR() + c.getG() + c.getB();
		else
			matriz[p.y][p.x] = 255;		
			
	}
	
}

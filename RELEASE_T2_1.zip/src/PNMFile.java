import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class PNMFile {

		
	public PNMFile()
	{	
		
		
	}	
	
	//Grava matriz no disco
	public static void saveToFile(int[][] mat, String filename) throws IOException
	{
		
		BufferedWriter out = new BufferedWriter(new FileWriter(filename + ".pnm"));
		
		if(Imagem.getCor().getTipoCor() == "C")
		{
			//Escreve Header Colorido
			out.write(String.format("P3\n %d %d\n255\n", mat[0].length,mat.length));
		}
		else
		{
			//Escrever Header Preto e Branco
			out.write(String.format("P2\n %d %d\n255\n", mat[0].length,mat.length));
		}
		
		//Escreve matriz
		for (int[] linha :  mat) {
			 for(int v : linha)
			 {
				 out.write(String.format("%d ", v));				 
			 }
			 out.write("\n");
		}	
		
		
		//Fecha arquivo
		out.close();
		
		
	}
}

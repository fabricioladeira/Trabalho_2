import javax.swing.text.StyledEditorKit.ForegroundAction;

public class Imagem{

	public static int[][] img = new int[100][100];	
	private static int largura = 100;
	private static int altura = 100;	
	private static Cor cor = new Cor(255,255,255,"G");
	
	public static int getLargura() {
		return largura;
	}

	public static void setLargura(int larg) {
		largura = larg;
	}

	public static int getAltura() {
		return altura;
	}

	public static void setAltura(int alt) {
		altura = alt;
	}
	
	public static void setPixel(Ponto p, Cor c )
	{		
		if(cor.getTipoCor()=="C")
			img[p.y][p.x] = c.getR() + c.getG() + c.getB();
		else
			img[p.y][p.x] = 255;
			
	}
	
	public static void addShape(Shape s, Cor c)
	{			
	
		int y = 0;		
		for (int[] linha :  s.matriz) {
			 int x = 0;
			 for(int v : linha)
			 {		
				if(s.matriz[x][y] != 0)
				{					
					setPixel(new Ponto(x,y), c);
					
					/*
					if(cor.getTipoCor() == "G")
						img[x][y] = 255;
					else
						img[x][y] = cor.getR() + cor.getG() + cor.getB();
						
						*/
				}
				
				x++;
			 }
			 y++;			 
		}		
		
	}
	
	public static int[][] getImagem()
	{
		return img;		
	}

	public static void setImagem(int larg, int alt)
	{
		largura = larg;
		altura = alt;		
		img = new int[largura][altura];
	}

	public static Cor getCor() {
		return cor;
	}

	public static void setCor(Cor pCor) {
		cor = pCor;
	}	
	
	
}


import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

///Trabalho Fabricio Jos� Loureiro Ladeira
/// Turma ADS SENAC 
/// Turno Noite
public class Principal {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
				
		String tipoCor;
		Cor cor;
		Shape shape;
		
		Scanner entrada = new Scanner(System.in); // J� consigo separara a linha e pegar o tipo n�o precisa
		
		String comand = "";	
		
		while (comand.toUpperCase() != "SAIR") {
			
			//Pega comando
			comand = entrada.next(); // Pega so o string do commando S� pegando o retirar  next line e pegar o tipo que eu quero direto.
			
		
			try{
			
				if(comand != "SAIR")
				{
					switch (comand.toUpperCase()) 
					{
						case "IMAGEM":
							//pega dados da largura altura e tipo de cor
							int largura = entrada.nextInt();
							int altura = entrada.nextInt();
							tipoCor = entrada.next();
							
							//Cria objeto cor com o tipo selecionado
							cor = new Cor(tipoCor);					
							
							Imagem.setImagem(largura, altura);						
							
							
							break;
		
						case "SALVAR":												
							//Implementar rotina de salvar
							String nomeArquivo = entrada.next();						
							PNMFile.saveToFile(Imagem.img, nomeArquivo);
							
							
							break;
							
							
						case "COR":
							//String parametros = parametros[0];
							int r = entrada.nextInt();
							int g = entrada.nextInt();
							int b = entrada.nextInt();
							tipoCor = entrada.next();
							
							if(tipoCor != null)
							{
								cor = new Cor(r,g,b, tipoCor);
							}
							else
							{
								cor = new Cor();
								cor.setR(r);
								cor.setG(g);
								cor.setB(b);
								cor.setTipoCor(Imagem.getCor().getTipoCor());
							}
							//Implementar rotina de salvar
							
							Imagem.setCor(cor);
							
							
							
							break;
							
						case "CIRCULO": //circulo X Y R	
							//Chama criculo;
							shape = new Circulo();
							((Circulo)shape).Draw(entrada.nextInt(), entrada.nextInt(), entrada.nextInt());						
							Imagem.addShape(shape, shape.cor);							
							break;
							
						case "RETA"://reta X0 Y0 X1 Y1																
							shape = new Reta();
							((Reta)shape).Draw(new Ponto(entrada.nextInt(),entrada.nextInt()),new Ponto(entrada.nextInt(),entrada.nextInt()));
							Imagem.addShape(shape, shape.cor);					
	
							break;
							
						case "RETANGULO": //retangulo X0 Y0 X1 Y1	
							shape = new Retangulo();
							((Retangulo)shape).Draw(entrada.nextInt(), entrada.nextInt(), entrada.nextInt(), entrada.nextInt());
							Imagem.addShape(shape, shape.cor);
							
							break;
							
						case "TRIANGULO": //triangulo X0 Y0 X1 Y1 X2 Y2
							shape = new Triangulo();
							((Triangulo)shape).Draw(entrada.nextInt(),entrada.nextInt(),entrada.nextInt(),entrada.nextInt(),entrada.nextInt(),entrada.nextInt());
							Imagem.addShape(shape, shape.cor);
							
							break;
							
						case "HELP": // HELP
							System.out.println("reta X0 Y0 X1 Y1");
							System.out.println("retangulo X0 Y0 X1 Y1");
							System.out.println("triangulo X0 Y0 X1 Y1 X2 Y2");
							System.out.println("circulo X Y R");
							System.out.println("cor <R G B | G>");
							System.out.println("salvar <nome arquivo>");
							System.out.println("imagem <largura> <altura> {C|G}");
							System.out.println("Sair");												
							System.out.format("tamanho imagem[%d][%d] %n ", Imagem.getLargura(), Imagem.getLargura());						
							break;
						
						
							
						default:
							System.out.println("Comando invalido digite HELP...");
							break;
					}
					
					System.out.println("OK...");
				
				}	
			
			}
			catch(Exception ex)
			{								
				MessageErro();	
			}
			
			
		}
		
			
		System.out.println("Fim");
		
		
		
	}
	
	public static void MessageErro()
	{
		System.out.println("Par�metro invalido...");	
	
	}

}


public class Circulo extends Shape
{	
	
	private static int i;
	private Ponto centro;
	private int raio;
	
	public Ponto getCentro() {
		return centro;
	}

	public void setCentro(Ponto centro) {
		this.centro = centro;
	}

	public int getRaio() {
		return raio;
	}

	public void setRaio(int raio) {
		this.raio = raio;
	}	
	
	
	public Circulo()
	{
	  //Seta altura maxima do desenho
	   setTamanhoMaximo();		
	}	
	
	public void Draw(double rc, double cc, double radius)	
	{	
	 
	
	   double radiusInterno = radius - 1;
	   
	   for(int row = 0; row < matriz.length; row++)
       {
		  i = row;
          for(int col = 0; col < matriz[i].length; col++)
          {
             double d = Math.sqrt((rc-row)*(rc-row)+(cc-col)*(cc-col));

             if(d <= radius && d >= radiusInterno)
             {
            	 if(Imagem.getCor().getTipoCor() == "G")
            		 matriz[row][col] = 255;
            	 else
            		 matriz[row][col] = cor.getR() + cor.getB() + cor.getG();           	 
            	 
             }
          }
       }		
	   
	  	
	   
		
	}

}

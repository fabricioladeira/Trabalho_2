
public class Retangulo extends Shape
{	
	
	///plotar linha
	public void Draw(int x1,int y1,int x2,int y2)
	{		
		Reta reta = new Reta();		
		reta.Draw(new Ponto(x1,y1), new Ponto(x2,y1));
		reta.Draw(new Ponto(x2,y1), new Ponto(x2,y2));
		reta.Draw(new Ponto(x1,y1), new Ponto(x1,y2));
		reta.Draw(new Ponto(x1,y2), new Ponto(x2,y2));
		
	}	
}


public class Ponto {

	public int x;
	public int y;	
	
	public Ponto(int px, int py)
	{
		x = px;
		y = py;
	}
}
